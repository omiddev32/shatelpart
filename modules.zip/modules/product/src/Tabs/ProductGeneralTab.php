<?php

namespace App\Product\Tabs;

use Laravel\Nova\Fields\{ID, BelongsTo, Text, Select, Number, Heading};

trait ProductGeneralTab
{
	public function generalTab($request)
	{
		return [

            ID::make(__('ID'),'id')
                ->sortable()
                ->onlyOnIndex(),

            Heading::make("
                <div class='w-full font-bold text-[#1C7EA5]'>
                    ". __("Product title") ." 
                </div>  
            ")->asHtml(),

            Text::make(__("Name"), 'name')
                ->rules('required')
                ->showOnPreview()
                ->help(__("English Name Only"))
                ->sortable(),

            Text::make(__("Display Name"), 'display_name')
                ->translatable()
                ->showOnPreview()
                ->rulesFor(config('app.locale'), [
                    'required',
                ]),
		];
	}
}