<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            /* General */
            $table->id();
            $table->string('name');
            $table->jsonb('display_name');

            /* Country Zone example => 'Global', 'Others', 'Eurozone' */
            $table->string('zone')->default('Global');

            /* Product type example => 'instant', 'prepaid_code', 'sms', 'hlr' */
            $table->string('type')->default('prepaid_code');

            /* Introduction */
            $table->jsonb('introduction')->nullable()->comment('Short Introduction');
            $table->boolean('introduction_status')->default(true);

            /* Application of the product */
            $table->jsonb('application')->nullable()->comment('Application of the product');
            $table->boolean('application_status')->default(true);

            /* Usage Method */
            $table->jsonb('usage_method')->nullable()->comment('Usage Method');
            $table->boolean('usage_method_status')->default(true);

            $table->jsonb('beneficiary_information')->nullable();
            $table->boolean('faq_status')->default(true);

             /* Media */
            $table->jsonb('videos')->nullable();
            $table->boolean('videos_status')->default(true)->comment('Videos Link');
            $table->string('image')->nullable();

            /* Cache Fields */
            $table->enum('price_type', ['fixed', 'range', 'single'])->default('fixed');
            $table->string('currency_price')->nullable();
            $table->float('min_price')->default(0);
            $table->float('max_price')->default(0);

            /* Statuses */
            $table->boolean('promotion')->default(false);
            $table->boolean('maintenance')->default(false);
            $table->boolean('status')->default(true);
            $table->timestamp('disabled_until')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
