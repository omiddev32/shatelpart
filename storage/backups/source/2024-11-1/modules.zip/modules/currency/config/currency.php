<?php

return [
    
    'services' => [
        'navasan' => [
            'url' => env('NAVASAN_URL', 'http://api.navasan.tech/latest'),
            'token' => env('NAVASAN_TOKEN', 'premlguEjQoNLMfoaT9m82mUgaurN7AY')
        ],
        'persianApi' => [
            'url' => env('NAVASAN_URL', 'http://api.navasan.tech/latest'),
            'token' => env('NAVASAN_TOKEN', 'freerWAEr5gn3wVZ4ViswXiXVCaxH5ef')
        ]
    ]

];
