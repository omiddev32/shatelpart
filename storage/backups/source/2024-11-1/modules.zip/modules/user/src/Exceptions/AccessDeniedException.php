<?php

namespace App\User\Exceptions;

use Exception;

class AccessDeniedException extends Exception
{
    //
}