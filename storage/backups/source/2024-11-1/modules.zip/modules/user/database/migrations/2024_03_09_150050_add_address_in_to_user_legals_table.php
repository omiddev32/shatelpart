<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('user_legals', function (Blueprint $table) {
            $table->string('address')->after('postal_code');
            $table->string('map_address')->after('address')->nullable();
            $table->string('address_image')->after('map_address')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('user_legals', function (Blueprint $table) {
            $table->dropColumn('address');
            $table->dropColumn('map_address');
            $table->dropColumn('address_image');
        });
    }
};
